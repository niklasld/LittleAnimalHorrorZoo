public class Snake {
   String color;
   int age;
   String mood;
   
   public Eat() {
   
   }
   public Move() {
   
   }
   public HuntRabbit() {
   
   }
}