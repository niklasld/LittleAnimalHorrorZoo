public class ScoreBoard {
   int score;
   int turnCount;
   
   public ShowScores() {
   
   }
   
   public TypeInitials() {
   
   }
   
   public ScoreBoardSystem() {
   
   }
   
   public ShowScoreBoard() {
   
   }
}