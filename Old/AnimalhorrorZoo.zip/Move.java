// importere random funktion fra java's utilities
import java.util.Random;

// Creating a calss called move
public class Move {
   int rabbitPosX = 1, rabbitPosY = 1, snakePosX = 9, snakePosY = 9;
   int oldPosX, oldPosY;
   //creating a public int with input, and using the randomiser to output a random number between 0 and the input given
   public int random(int input) {
      // creates a new random generator object
		Random generator = new Random();
      
      // Creates an integer variable called random and puts in a new random number between 0 and input number given
      int random = generator.nextInt(input);
      
      //returns the value on the random variable.
		return random;		
   }
   
   public String rabbitLoc() {
      String loc = "Rabbit; I am currently on position ("+rabbitPosX+","+rabbitPosY+")";
      return loc;
   }
   public void moveRabbit() {
      
      // made new object called rabbitMoveRandom
      Move rabbitMoveRandom = new Move();
      
      // made variable and set it equal to the random output of 0 or 1 
      int random = rabbitMoveRandom.random(2);
      // We move the rabbit on the x axis
      if (random == 0) {
         //If rabbit is on the x coord 0 we will move it forward  1 point on the x axis
            if (rabbitPosX == 0){
               // We set oldPosX = rabbitPosX so we can see output the old position and new
               oldPosX = rabbitPosX;
               // We add 1 to the rabbit's position to make it move 1 point on the grid
               rabbitPosX++;
               // We print out the rabbits old position and new position in text                
               System.out.println("Rabbit; I moved from ("+oldPosX+","+rabbitPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
            }
            // if the rabbits position on the x axis = 10 it will move 1 point backwards on the x axis
            else if (rabbitPosX == 10){
            // set the old position of the rabbit equals rabbit's new position
               oldPosX = rabbitPosX;
            // we subtract 1 from the rabbit's position   
               rabbitPosX--;
            // we print out the rabbits old position and make it tell us it's new position   
               System.out.println("Rabbit; I moved from ("+oldPosX+","+rabbitPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
            }
            else {
            // we set our variable random to be equal random number between 0 and 1
               random = rabbitMoveRandom.random(2);
            // if random = 0 the rabbit moves forward
               if(random==0) {
            // we set the variable olPosX to be equal to the the current position x   
                  oldPosX = rabbitPosX;
            // we add +1 to the rabbits current position.
                  rabbitPosX++;
            // we print out the rabbits old position and make it tell us it's new position   
                  System.out.println("Rabbit; I moved from ("+oldPosX+","+rabbitPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
               }
            // if random == 1 or any other number re move the rabbit backwards on the x axis
               else{
            // we set the variable olPosX to be equal to the the current position x
                  oldPosX = rabbitPosX;
            // we add -1 to the rabbits current position.
                  rabbitPosX--;
            // we print out the rabbits old position and make it tell us it's new position   
                  System.out.println("Rabbit; I moved from ("+oldPosX+","+rabbitPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
               
               }
            }
        }
         else {
         // We move the rabbit on the y axis
            if (rabbitPosY == 0){
               // We set oldPosY = rabbitPosY so we can see output the old position and new
               oldPosY = rabbitPosY;
               // We add 1 to the rabbit's position to make it move 1 point on the grid
               rabbitPosY++;
               // We print out the rabbits old position and new position in text                
               System.out.println("Rabbit; I moved from ("+rabbitPosX+","+oldPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
            }
            // if the rabbits position on the Y axis = 10 it will move 1 point backwards on the Y axis
            else if (rabbitPosY == 10){
            // set the old position of the rabbit equals rabbit's new position
               oldPosY = rabbitPosY;
            // we subtract 1 from the rabbit's position   
               rabbitPosY--;
            // we print out the rabbits old position and make it tell us it's new position   
               System.out.println("Rabbit; I moved from ("+rabbitPosX+","+oldPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
            }
            else {
            // we set our variable random to be equal random number between 0 and 1
               random = rabbitMoveRandom.random(2);
            // if random = 0 the rabbit moves forward
               if(random==0) {
            // we set the variable olPosX to be equal to the the current position Y   
                  oldPosY = rabbitPosY;
            // we add +1 to the rabbits current position.
                  rabbitPosY++;
            // we print out the rabbits old position and make it tell us it's new position   
                  System.out.println("Rabbit; I moved from ("+rabbitPosX+","+oldPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
               }
            // if random == 1 or any other number re move the rabbit backwards on the Y axis
               else{
            // we set the variable olPosX to be equal to the the current position Y
                  oldPosY = rabbitPosY;
            // we add -1 to the rabbits current position.
                  rabbitPosY--;
            // we print out the rabbits old position and make it tell us it's new position   
                  System.out.println("Rabbit; I moved from ("+rabbitPosX+","+oldPosY+") to ("+rabbitPosX+","+rabbitPosY+")");
               
               }
            }
         
         }
   }
   
      public void moveSnake() {
      
      // made new object called snakeMoveRandom
      Move snakeMoveRandom = new Move();
      
      // made variable and set it equal to the random output of 0 or 1 
      int random = snakeMoveRandom.random(2);
      // We move the snake on the x axis
      if (random == 0) {
         //If snake is on the x coord 0 we will move it forward  1 point on the x axis
            if (snakePosX == 0){
               // We set oldPosX = snakePosX so we can see output the old position and new
               oldPosX = snakePosX;
               // We add 1 to the snake's position to make it move 1 point on the grid
               snakePosX++;
               // We print out the snakes old position and new position in text                
               System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
            }
            // if the snakes position on the x axis = 10 it will move 1 point backwards on the x axis
            else if (snakePosX == 10){
            // set the old position of the snake equals snake's new position
               oldPosX = snakePosX;
            // we subtract 1 from the snake's position   
               snakePosX--;
               // We print out the snakes old position and new position in text                
               System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
            }
            else {
            // we set our variable random to be equal random number between 0 and 1
               random = snakeMoveRandom.random(2);
            // if random = 0 the snake moves forward
               if(random==0) {
            // we set the variable olPosX to be equal to the the current position x   
                  oldPosX = snakePosX;
            // we add +1 to the snakes current position.
                  snakePosX++;
            // We print out the snakes old position and new position in text                
                  System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
               }
            // if random == 1 or any other number re move the snake backwards on the x axis
               else{
            // we set the variable olPosX to be equal to the the current position x
                  oldPosX = snakePosX;
            // we add -1 to the snakes current position.
                  snakePosX--;
            // we print out the snakes old position and make it tell us it's new position   
                  System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
               
               }
            }
        }
         else {
         // We move the snakeon the y axis
            if (snakePosY == 0){
               // We set oldPosY = snakePosY so we can see output the old position and new
               oldPosY = snakePosY;
               // We add 1 to the snake's position to make it move 1 point on the grid
               snakePosY++;
               // We print out the snakes old position and new position in text                
               System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
            }
            // if the snakes position on the Y axis = 10 it will move 1 point backwards on the Y axis
            else if (snakePosY == 10){
            // set the old position of the rabbit equals snake's new position
               oldPosY = snakePosY;
            // we subtract 1 from the snake's position   
               snakePosY--;
            // we print out the snakes old position and make it tell us it's new position   
               System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
                           }
            else {
            // we set our variable random to be equal random number between 0 and 1
               random = snakeMoveRandom.random(2);
            // if random = 0 the snake moves forward
               if(random==0) {
            // we set the variable olPosX to be equal to the the current position Y   
                  oldPosY = snakePosY;
            // we add +1 to the snakes current position.
                  snakePosY++;
            // we print out the snakes old position and make it tell us it's new position   
                  System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
               }
            // if random == 1 or any other number re move the snake backwards on the Y axis
               else{
            // we set the variable olPosX to be equal to the the current position Y
                  oldPosY = snakePosY;
            // we add -1 to the snakes current position.
                  snakePosY--;
            // we print out the snakes old position and make it tell us it's new position   
                  System.out.println("Snake; I moved from ("+oldPosX+","+snakePosY+") to ("+snakePosX+","+snakePosY+")");
               
               }
            }
         
         }
   }
} 