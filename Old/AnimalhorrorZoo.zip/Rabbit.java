public class Rabbit {
   String color;
   int age;
   String mood;
   
   public Beg() {
   
   }
   
   public Move() {
      
   }
   
   public DetectSnake() {
   
   }
}