public class Player {
   
   public ChooseAnimal() {
   
   }
   
   public TypeScoreBoardInit() {

   }
}