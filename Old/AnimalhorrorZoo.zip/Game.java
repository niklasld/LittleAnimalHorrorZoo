import java.util.Scanner;

public class Game {
   public static void main(String[] args) {
      Move rabbit = new Move();
      Move snake = new Move();
      while(rabbit.rabbitPosX != snake.snakePosX || rabbit.rabbitPosY != snake.snakePosY) {
         snake.moveSnake();
         rabbit.moveRabbit();
      }
      System.out.println("Game over rabbit("+rabbit.rabbitPosX+","+rabbit.rabbitPosY+") snake("+snake.snakePosX+","+snake.snakePosY+")");
      
   }
}

